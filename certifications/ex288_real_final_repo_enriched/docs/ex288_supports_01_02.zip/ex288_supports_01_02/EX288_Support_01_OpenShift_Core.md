# Support 01 — OpenShift Core

## Objectif du support
Maîtriser les bases indispensables d’OpenShift avant d’attaquer les builds, S2I, Helm, Kustomize et le troubleshooting avancé.

Ce support couvre :
- projects et contextes
- séparation logique des ressources
- déploiement d’une application simple
- Services et Routes
- Deployment
- DeploymentConfig
- scaling
- variables d’environnement
- requests / limits
- vérifications de base

---

# 1. Vue d’ensemble

OpenShift repose sur Kubernetes, mais ajoute plusieurs objets et comportements utiles :
- `Project`
- `Route`
- `ImageStream`
- `DeploymentConfig`

## Schéma global

```mermaid
flowchart TD
    U[Utilisateur / oc CLI] --> P[Project]
    P --> D[Deployment]
    D --> RS[ReplicaSet]
    RS --> POD[Pod]
    POD --> SVC[Service]
    SVC --> ROUTE[Route]
    ROUTE --> CLIENT[Client HTTP]
```

---

# 2. Projects et contextes

## 2.1 Rôle d’un Project
Un `Project` OpenShift est l’équivalent pratique d’un namespace Kubernetes enrichi :
- isolation logique
- séparation des ressources
- contrôle d’accès
- contexte de travail courant

## 2.2 Pourquoi c’est critique à l’examen
Beaucoup d’erreurs viennent d’un mauvais projet courant :
- ressource créée au mauvais endroit
- vérification dans le mauvais projet
- faux diagnostic “No resources found”

## 2.3 Commandes réflexes

```bash
oc whoami
oc project
oc projects
oc new-project ex288-01a
oc project ex288-01a
```

## 2.4 Schéma de séparation

```mermaid
flowchart LR
    A[Project ex288-01c-a] --> A1[ConfigMap cm-a]
    B[Project ex288-01c-b] --> B1[ConfigMap cm-b]
```

---

# 3. Deployment d’une application simple

## 3.1 Qu’est-ce qu’un Deployment
Un `Deployment` gère l’état désiré d’une application stateless :
- nombre de replicas
- image
- labels / selectors
- stratégie de mise à jour

## 3.2 Chaîne de création

```mermaid
flowchart TD
    DEP[Deployment] --> RS[ReplicaSet]
    RS --> POD1[Pod]
    RS --> POD2[Pod]
```

## 3.3 Champs importants
- `replicas`
- `selector.matchLabels`
- `template.metadata.labels`
- `template.spec.containers[].image`

## 3.4 Commandes utiles

```bash
oc get deploy
oc describe deploy web
oc rollout status deploy/web
oc get pods
```

---

# 4. Service

## 4.1 Rôle
Le `Service` expose un ou plusieurs Pods via un point stable :
- IP stable interne
- sélection par labels
- abstraction réseau

## 4.2 Notion d’Endpoints
Les `Endpoints` montrent les Pods réellement associés au Service.

## 4.3 Commandes réflexes

```bash
oc get svc
oc get endpoints
oc describe svc web
```

## 4.4 Schéma

```mermaid
flowchart LR
    P1[Pod 10.x app=web] --> SVC[Service web]
    P2[Pod 10.x app=web] --> SVC
```

---

# 5. Route

## 5.1 Rôle
La `Route` est un objet OpenShift qui expose un Service à l’extérieur du cluster.

## 5.2 Chaîne complète

```mermaid
flowchart LR
    CLIENT[Client] --> ROUTE[Route]
    ROUTE --> SVC[Service]
    SVC --> POD[Pod]
```

## 5.3 Diagnostic rapide d’une Route cassée
1. `oc get route`
2. `oc describe route`
3. `oc get svc`
4. `oc get endpoints`
5. `oc get pods`

## 5.4 Important sur CRC
Une Route peut être correcte côté cluster même si `curl` local échoue à cause du DNS de Windows.

---

# 6. DeploymentConfig

## 6.1 Rôle
`DeploymentConfig` est un objet historique OpenShift encore présent sur CRC/OpenShift 4.x, bien que déprécié.

## 6.2 Différence simple avec Deployment
- `Deployment` : objet Kubernetes standard
- `DeploymentConfig` : objet OpenShift avec triggers natifs historiques

## 6.3 Schéma

```mermaid
flowchart TD
    DC[DeploymentConfig] --> RC[ReplicationController]
    RC --> POD[Pod]
```

## 6.4 Commandes utiles

```bash
oc get dc
oc describe dc dc-app
```

---

# 7. Variables d’environnement

Les variables d’environnement servent à injecter une configuration simple.

Exemple :
```yaml
env:
  - name: APP_MODE
    value: test
```

Vérification :
- `oc describe deploy`
- `oc exec`
- logs applicatifs

---

# 8. Scaling

## 8.1 Commande
```bash
oc scale deploy/res-app --replicas=2
```

## 8.2 Vérification
```bash
oc get deploy
oc get pods
oc describe deploy res-app
```

---

# 9. Requests et limits

## 9.1 Objectif
Décrire les ressources minimales et maximales du conteneur.

- `requests` : minimum réservé
- `limits` : plafond maximum

## 9.2 Exemple
```yaml
resources:
  requests:
    cpu: 100m
    memory: 128Mi
  limits:
    cpu: 300m
    memory: 256Mi
```

## 9.3 Schéma conceptuel

```mermaid
flowchart LR
    REQ[Requests] --> SCHED[Scheduling]
    LIM[Limits] --> RUNTIME[Runtime enforcement]
```

---

# 10. Commandes de vérification minimales du support 01

```bash
oc whoami
oc project
oc projects
oc get all
oc get svc,route,endpoints
oc describe deploy <name>
oc describe dc <name>
oc rollout status deploy/<name>
oc get events --sort-by=.lastTimestamp | tail -n 30
```

---

# 11. Erreurs fréquentes

## 11.1 Mauvais projet courant
Réflexe :
```bash
oc project
oc projects
```

## 11.2 Service sans endpoints
Réflexe :
```bash
oc get endpoints
oc describe svc <name>
oc get pods --show-labels
```

## 11.3 Déploiement non disponible
Réflexe :
```bash
oc describe deploy <name>
oc get pods
oc describe pod <pod>
```

---

# 12. Ce qu’il faut maîtriser avant le support 02
Tu dois être capable de :
- créer et changer de projet
- déployer une app simple
- créer Service et Route
- vérifier Endpoints
- lire un Deployment
- lire un DeploymentConfig
- scaler
- poser env / requests / limits