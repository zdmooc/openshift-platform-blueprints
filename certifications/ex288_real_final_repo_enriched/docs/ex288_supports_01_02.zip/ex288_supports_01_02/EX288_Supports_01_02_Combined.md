# EX288 — Supports 01 et 02\n\n## Fichiers inclus\n- Support 01 — OpenShift Core\n- Support 02 — Images et registre\n\n---\n\n# Support 01 — OpenShift Core

## Objectif du support
Maîtriser les bases indispensables d’OpenShift avant d’attaquer les builds, S2I, Helm, Kustomize et le troubleshooting avancé.

Ce support couvre :
- projects et contextes
- séparation logique des ressources
- déploiement d’une application simple
- Services et Routes
- Deployment
- DeploymentConfig
- scaling
- variables d’environnement
- requests / limits
- vérifications de base

---

# 1. Vue d’ensemble

OpenShift repose sur Kubernetes, mais ajoute plusieurs objets et comportements utiles :
- `Project`
- `Route`
- `ImageStream`
- `DeploymentConfig`

## Schéma global

```mermaid
flowchart TD
    U[Utilisateur / oc CLI] --> P[Project]
    P --> D[Deployment]
    D --> RS[ReplicaSet]
    RS --> POD[Pod]
    POD --> SVC[Service]
    SVC --> ROUTE[Route]
    ROUTE --> CLIENT[Client HTTP]
```

---

# 2. Projects et contextes

## 2.1 Rôle d’un Project
Un `Project` OpenShift est l’équivalent pratique d’un namespace Kubernetes enrichi :
- isolation logique
- séparation des ressources
- contrôle d’accès
- contexte de travail courant

## 2.2 Pourquoi c’est critique à l’examen
Beaucoup d’erreurs viennent d’un mauvais projet courant :
- ressource créée au mauvais endroit
- vérification dans le mauvais projet
- faux diagnostic “No resources found”

## 2.3 Commandes réflexes

```bash
oc whoami
oc project
oc projects
oc new-project ex288-01a
oc project ex288-01a
```

## 2.4 Schéma de séparation

```mermaid
flowchart LR
    A[Project ex288-01c-a] --> A1[ConfigMap cm-a]
    B[Project ex288-01c-b] --> B1[ConfigMap cm-b]
```

---

# 3. Deployment d’une application simple

## 3.1 Qu’est-ce qu’un Deployment
Un `Deployment` gère l’état désiré d’une application stateless :
- nombre de replicas
- image
- labels / selectors
- stratégie de mise à jour

## 3.2 Chaîne de création

```mermaid
flowchart TD
    DEP[Deployment] --> RS[ReplicaSet]
    RS --> POD1[Pod]
    RS --> POD2[Pod]
```

## 3.3 Champs importants
- `replicas`
- `selector.matchLabels`
- `template.metadata.labels`
- `template.spec.containers[].image`

## 3.4 Commandes utiles

```bash
oc get deploy
oc describe deploy web
oc rollout status deploy/web
oc get pods
```

---

# 4. Service

## 4.1 Rôle
Le `Service` expose un ou plusieurs Pods via un point stable :
- IP stable interne
- sélection par labels
- abstraction réseau

## 4.2 Notion d’Endpoints
Les `Endpoints` montrent les Pods réellement associés au Service.

## 4.3 Commandes réflexes

```bash
oc get svc
oc get endpoints
oc describe svc web
```

## 4.4 Schéma

```mermaid
flowchart LR
    P1[Pod 10.x app=web] --> SVC[Service web]
    P2[Pod 10.x app=web] --> SVC
```

---

# 5. Route

## 5.1 Rôle
La `Route` est un objet OpenShift qui expose un Service à l’extérieur du cluster.

## 5.2 Chaîne complète

```mermaid
flowchart LR
    CLIENT[Client] --> ROUTE[Route]
    ROUTE --> SVC[Service]
    SVC --> POD[Pod]
```

## 5.3 Diagnostic rapide d’une Route cassée
1. `oc get route`
2. `oc describe route`
3. `oc get svc`
4. `oc get endpoints`
5. `oc get pods`

## 5.4 Important sur CRC
Une Route peut être correcte côté cluster même si `curl` local échoue à cause du DNS de Windows.

---

# 6. DeploymentConfig

## 6.1 Rôle
`DeploymentConfig` est un objet historique OpenShift encore présent sur CRC/OpenShift 4.x, bien que déprécié.

## 6.2 Différence simple avec Deployment
- `Deployment` : objet Kubernetes standard
- `DeploymentConfig` : objet OpenShift avec triggers natifs historiques

## 6.3 Schéma

```mermaid
flowchart TD
    DC[DeploymentConfig] --> RC[ReplicationController]
    RC --> POD[Pod]
```

## 6.4 Commandes utiles

```bash
oc get dc
oc describe dc dc-app
```

---

# 7. Variables d’environnement

Les variables d’environnement servent à injecter une configuration simple.

Exemple :
```yaml
env:
  - name: APP_MODE
    value: test
```

Vérification :
- `oc describe deploy`
- `oc exec`
- logs applicatifs

---

# 8. Scaling

## 8.1 Commande
```bash
oc scale deploy/res-app --replicas=2
```

## 8.2 Vérification
```bash
oc get deploy
oc get pods
oc describe deploy res-app
```

---

# 9. Requests et limits

## 9.1 Objectif
Décrire les ressources minimales et maximales du conteneur.

- `requests` : minimum réservé
- `limits` : plafond maximum

## 9.2 Exemple
```yaml
resources:
  requests:
    cpu: 100m
    memory: 128Mi
  limits:
    cpu: 300m
    memory: 256Mi
```

## 9.3 Schéma conceptuel

```mermaid
flowchart LR
    REQ[Requests] --> SCHED[Scheduling]
    LIM[Limits] --> RUNTIME[Runtime enforcement]
```

---

# 10. Commandes de vérification minimales du support 01

```bash
oc whoami
oc project
oc projects
oc get all
oc get svc,route,endpoints
oc describe deploy <name>
oc describe dc <name>
oc rollout status deploy/<name>
oc get events --sort-by=.lastTimestamp | tail -n 30
```

---

# 11. Erreurs fréquentes

## 11.1 Mauvais projet courant
Réflexe :
```bash
oc project
oc projects
```

## 11.2 Service sans endpoints
Réflexe :
```bash
oc get endpoints
oc describe svc <name>
oc get pods --show-labels
```

## 11.3 Déploiement non disponible
Réflexe :
```bash
oc describe deploy <name>
oc get pods
oc describe pod <pod>
```

---

# 12. Ce qu’il faut maîtriser avant le support 02
Tu dois être capable de :
- créer et changer de projet
- déployer une app simple
- créer Service et Route
- vérifier Endpoints
- lire un Deployment
- lire un DeploymentConfig
- scaler
- poser env / requests / limits\n\n---\n\n# Support 02 — Images et registre

## Objectif du support
Comprendre comment OpenShift gère les images applicatives :
- ImageStreams
- build d’image depuis Containerfile
- registre interne
- consommation d’image dans le même projet ou dans un autre projet

---

# 1. Vue d’ensemble

Le cluster fournit :
- un **registre interne**
- des **ImageStreams**
- des builds intégrés
- des déploiements qui consomment ces images

## Schéma global

```mermaid
flowchart LR
    SRC[Code / Containerfile] --> BUILD[BuildConfig]
    BUILD --> IS[ImageStream]
    IS --> REG[Internal Registry]
    REG --> DEPLOY[Deployment / DeploymentConfig]
    DEPLOY --> POD[Pod]
```

---

# 2. ImageStream

## 2.1 Définition
Un `ImageStream` est un objet OpenShift qui référence des tags d’images.

## 2.2 Pourquoi c’est utile
- suivre les versions
- découpler build et déploiement
- déclencher des changements d’image

## 2.3 Commandes
```bash
oc get is
oc describe is basic-node
```

---

# 3. Registre interne

## 3.1 Rôle
Le registre interne OpenShift stocke les images construites ou importées dans le cluster.

## 3.2 Commande utile
```bash
oc registry info
```

## 3.3 Exemple de repository
```text
image-registry.openshift-image-registry.svc:5000/ex288-02b/basic-node:latest
```

## 3.4 Schéma

```mermaid
flowchart LR
    BC[BuildConfig] --> REG[Internal Registry]
    REG --> NS1[Project ex288-02b]
    REG --> NS2[Project ex288-02c]
```

---

# 4. BuildConfig binaire avec Docker strategy

## 4.1 Objectif
Construire une image à partir d’un dossier local contenant :
- `Containerfile`
- code applicatif

## 4.2 Type de source
Dans ton lab 02B :
- `source.type: Binary`
- `strategy: dockerStrategy`

## 4.3 Schéma

```mermaid
flowchart TD
    LOCAL[shared/apps/basic-node] --> UPLOAD[oc start-build --from-dir]
    UPLOAD --> BC[BuildConfig binary]
    BC --> BUILD[Build Pod]
    BUILD --> IS[ImageStreamTag latest]
```

## 4.4 Commandes de lecture
```bash
oc get build,is
oc describe bc basic-node-binary
oc logs build/basic-node-binary-1
```

---

# 5. Containerfile / image custom

## 5.1 Pourquoi c’est important
Tu dois savoir construire une image personnalisée.

## 5.2 Structure typique
```dockerfile
FROM registry.access.redhat.com/ubi9/nodejs-20:latest
WORKDIR /opt/app-root/src
COPY package.json server.js ./
RUN npm install --omit=dev || true
EXPOSE 8080
CMD ["node", "server.js"]
```

## 5.3 Concepts
- `FROM`
- `WORKDIR`
- `COPY`
- `RUN`
- `EXPOSE`
- `CMD`

---

# 6. Déploiement depuis l’image construite

## 6.1 Chaîne logique
Une fois l’image construite :
- elle est poussée dans le registre interne
- le Deployment peut consommer l’image

## 6.2 Schéma

```mermaid
flowchart LR
    IS[ImageStream latest] --> REG[Internal Registry]
    REG --> DEPLOY[Deployment]
    DEPLOY --> POD[Pod Running]
    POD --> SVC[Service]
    SVC --> ROUTE[Route]
```

## 6.3 Vérifications
```bash
oc rollout status deploy/basic-node
oc get svc,route,endpoints
oc describe deploy basic-node
```

---

# 7. Pull cross-namespace

## 7.1 Problème
Un projet ne peut pas forcément consommer une image d’un autre projet.

## 7.2 Solution
Donner le rôle `system:image-puller` :

```bash
oc policy add-role-to-user system:image-puller system:serviceaccount:ex288-02c:default -n ex288-02b
```

## 7.3 Schéma

```mermaid
flowchart LR
    P1[Project ex288-02b] --> IMG[basic-node:latest]
    IMG --> REG[Internal Registry]
    SA[ServiceAccount ex288-02c:default] --> ROLE[system:image-puller]
    ROLE --> REG
    REG --> P2[Deployment in ex288-02c]
```

---

# 8. Pattern validé dans tes labs

## 8.1 Lab 02A
Création d’un `ImageStream`.

## 8.2 Lab 02B
Build binaire :
- ImageStream
- BuildConfig
- build depuis `Containerfile`
- push vers le registre interne
- déploiement depuis l’image construite
- service + route + endpoints

## 8.3 Lab 02C
Consommation cross-namespace :
- rôle `system:image-puller`
- déploiement dans un second projet
- consommation de l’image du premier projet

---

# 9. Commandes minimales du support 02

```bash
oc registry info
oc get is
oc describe is <name>

oc get bc,build
oc describe bc <name>
oc logs build/<build-name>

oc rollout status deploy/<name>
oc get svc,route,endpoints
oc describe deploy <name>
```

---

# 10. Erreurs fréquentes

## 10.1 Chemin local erroné pour `--from-dir`
Réflexe :
- vérifier ton dossier courant
- utiliser le chemin Git Bash absolu

## 10.2 Build incomplet ou en erreur
Réflexe :
```bash
oc get build
oc logs build/<name>
oc describe bc <name>
```

## 10.3 Image non trouvée au déploiement
Réflexe :
```bash
oc get is
oc describe is <name>
```

## 10.4 Pull cross-namespace refusé
Réflexe :
- vérifier le rôle `system:image-puller`
- vérifier les namespaces source et cible

---

# 11. Différence entre les notions clés du support 02

## 11.1 ImageStream
Référence logique d’image.

## 11.2 Internal Registry
Stockage réel des images du cluster.

## 11.3 BuildConfig
Recette de build.

## 11.4 Build
Exécution réelle du build.

## 11.5 Deployment
Consommateur de l’image.

---

# 12. Ce qu’il faut maîtriser avant le support 03
Tu dois être capable de :
- créer un ImageStream
- lire un ImageStream
- créer un BuildConfig binaire Docker strategy
- lancer un build depuis un dossier local
- vérifier le build
- déployer l’image construite
- consommer une image d’un autre projet via `system:image-puller`\n