# Support 02 — Images et registre

## Objectif du support
Comprendre comment OpenShift gère les images applicatives :
- ImageStreams
- build d’image depuis Containerfile
- registre interne
- consommation d’image dans le même projet ou dans un autre projet

---

# 1. Vue d’ensemble

Le cluster fournit :
- un **registre interne**
- des **ImageStreams**
- des builds intégrés
- des déploiements qui consomment ces images

## Schéma global

```mermaid
flowchart LR
    SRC[Code / Containerfile] --> BUILD[BuildConfig]
    BUILD --> IS[ImageStream]
    IS --> REG[Internal Registry]
    REG --> DEPLOY[Deployment / DeploymentConfig]
    DEPLOY --> POD[Pod]
```

---

# 2. ImageStream

## 2.1 Définition
Un `ImageStream` est un objet OpenShift qui référence des tags d’images.

## 2.2 Pourquoi c’est utile
- suivre les versions
- découpler build et déploiement
- déclencher des changements d’image

## 2.3 Commandes
```bash
oc get is
oc describe is basic-node
```

---

# 3. Registre interne

## 3.1 Rôle
Le registre interne OpenShift stocke les images construites ou importées dans le cluster.

## 3.2 Commande utile
```bash
oc registry info
```

## 3.3 Exemple de repository
```text
image-registry.openshift-image-registry.svc:5000/ex288-02b/basic-node:latest
```

## 3.4 Schéma

```mermaid
flowchart LR
    BC[BuildConfig] --> REG[Internal Registry]
    REG --> NS1[Project ex288-02b]
    REG --> NS2[Project ex288-02c]
```

---

# 4. BuildConfig binaire avec Docker strategy

## 4.1 Objectif
Construire une image à partir d’un dossier local contenant :
- `Containerfile`
- code applicatif

## 4.2 Type de source
Dans ton lab 02B :
- `source.type: Binary`
- `strategy: dockerStrategy`

## 4.3 Schéma

```mermaid
flowchart TD
    LOCAL[shared/apps/basic-node] --> UPLOAD[oc start-build --from-dir]
    UPLOAD --> BC[BuildConfig binary]
    BC --> BUILD[Build Pod]
    BUILD --> IS[ImageStreamTag latest]
```

## 4.4 Commandes de lecture
```bash
oc get build,is
oc describe bc basic-node-binary
oc logs build/basic-node-binary-1
```

---

# 5. Containerfile / image custom

## 5.1 Pourquoi c’est important
Tu dois savoir construire une image personnalisée.

## 5.2 Structure typique
```dockerfile
FROM registry.access.redhat.com/ubi9/nodejs-20:latest
WORKDIR /opt/app-root/src
COPY package.json server.js ./
RUN npm install --omit=dev || true
EXPOSE 8080
CMD ["node", "server.js"]
```

## 5.3 Concepts
- `FROM`
- `WORKDIR`
- `COPY`
- `RUN`
- `EXPOSE`
- `CMD`

---

# 6. Déploiement depuis l’image construite

## 6.1 Chaîne logique
Une fois l’image construite :
- elle est poussée dans le registre interne
- le Deployment peut consommer l’image

## 6.2 Schéma

```mermaid
flowchart LR
    IS[ImageStream latest] --> REG[Internal Registry]
    REG --> DEPLOY[Deployment]
    DEPLOY --> POD[Pod Running]
    POD --> SVC[Service]
    SVC --> ROUTE[Route]
```

## 6.3 Vérifications
```bash
oc rollout status deploy/basic-node
oc get svc,route,endpoints
oc describe deploy basic-node
```

---

# 7. Pull cross-namespace

## 7.1 Problème
Un projet ne peut pas forcément consommer une image d’un autre projet.

## 7.2 Solution
Donner le rôle `system:image-puller` :

```bash
oc policy add-role-to-user system:image-puller system:serviceaccount:ex288-02c:default -n ex288-02b
```

## 7.3 Schéma

```mermaid
flowchart LR
    P1[Project ex288-02b] --> IMG[basic-node:latest]
    IMG --> REG[Internal Registry]
    SA[ServiceAccount ex288-02c:default] --> ROLE[system:image-puller]
    ROLE --> REG
    REG --> P2[Deployment in ex288-02c]
```

---

# 8. Pattern validé dans tes labs

## 8.1 Lab 02A
Création d’un `ImageStream`.

## 8.2 Lab 02B
Build binaire :
- ImageStream
- BuildConfig
- build depuis `Containerfile`
- push vers le registre interne
- déploiement depuis l’image construite
- service + route + endpoints

## 8.3 Lab 02C
Consommation cross-namespace :
- rôle `system:image-puller`
- déploiement dans un second projet
- consommation de l’image du premier projet

---

# 9. Commandes minimales du support 02

```bash
oc registry info
oc get is
oc describe is <name>

oc get bc,build
oc describe bc <name>
oc logs build/<build-name>

oc rollout status deploy/<name>
oc get svc,route,endpoints
oc describe deploy <name>
```

---

# 10. Erreurs fréquentes

## 10.1 Chemin local erroné pour `--from-dir`
Réflexe :
- vérifier ton dossier courant
- utiliser le chemin Git Bash absolu

## 10.2 Build incomplet ou en erreur
Réflexe :
```bash
oc get build
oc logs build/<name>
oc describe bc <name>
```

## 10.3 Image non trouvée au déploiement
Réflexe :
```bash
oc get is
oc describe is <name>
```

## 10.4 Pull cross-namespace refusé
Réflexe :
- vérifier le rôle `system:image-puller`
- vérifier les namespaces source et cible

---

# 11. Différence entre les notions clés du support 02

## 11.1 ImageStream
Référence logique d’image.

## 11.2 Internal Registry
Stockage réel des images du cluster.

## 11.3 BuildConfig
Recette de build.

## 11.4 Build
Exécution réelle du build.

## 11.5 Deployment
Consommateur de l’image.

---

# 12. Ce qu’il faut maîtriser avant le support 03
Tu dois être capable de :
- créer un ImageStream
- lire un ImageStream
- créer un BuildConfig binaire Docker strategy
- lancer un build depuis un dossier local
- vérifier le build
- déployer l’image construite
- consommer une image d’un autre projet via `system:image-puller`